PuppetPin 1.1.0
========================================

パペットピン風のメッシュ変形。親子関係と物理演算で髪や紐も揺れる

画像のアルファから三角形のメッシュを作り、ピンを動かして画像を変形します。なるべく形を保ったまま曲がるので、キャラクターの腕を振る、ロゴをぐにゃっと曲げるといった動きが簡単に作れます。
ピンは最大 16 本。動かすピンのほか、回転と大きさを決めるピン、硬さを足すピン、重なりの前後を決めるピンがあります。
1.1.0 からピンに親子関係を付けられます。子のピンは親の動きと回転について行き、「物理演算で揺らす」をオンにすると、重力・バネ・減衰・風に従って親からぶら下がって揺れます。頭を動かすだけで髪の毛や紐、しっぽが遅れてしなる動きになります。親を付けなければ今まで通りすべて手動です。

■ 使い方

  1. Fusion ページで PuppetPin ノードを追加し、アルファのある画像をつなぐ
  2. 「ピンを配置」をオンにして、ピンを有効にし画像の上に置く
  3. 「ピンを配置」をオフにして、位置ピンをキーフレームで動かす
  4. 髪や紐を揺らすとき: 根元から先へピンを並べ、それぞれの「親」を1つ前のピンにして「物理演算で揺らす」をオン。「Physics（物理）」ページで重力や風を調整

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。Studio 限定（無料版では動かない）の可能性があります

■ クレジット

  変形の手法: As-Rigid-As-Possible Surface Modeling (Sorkine & Alexa, 2007)
