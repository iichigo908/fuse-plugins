BrushPaint 1.0.0
========================================

筆・水彩などのブラシストローク

ビューアに直接描いた線に、筆・水彩・かすれ・鉛筆などの質感をつけるペイントノードです。1つのノードで 8 本まで描けて、ストロークごとにブラシと色を変えられます。
入力のないジェネレーターなので、Merge で背景に重ねて使います。描き順アニメ（ライトオン）で、線を描いていく様子も作れます。

■ 使い方

  1. Fusion ページで BrushPaint ノードを追加し、Merge の Foreground につなぐ
  2. ノードを選んでビューアに線を描く（最初から鉛筆モード）
  3. 2 本目以降は「Stroke 2」などのページで「このストロークを描く」を押してから描く

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。Studio 限定（無料版では動かない）の可能性があります
