MotionTexture 1.0.0
========================================

傷・汚れ、しわ紙、ノイズの動くテクスチャを重ねるノード

傷・汚れ、しわ紙、ノイズのテクスチャを GPU で作り、動かして画像に重ねるノードです。テクスチャは止めておく、数コマごとに変える（手作り風のガタつき）、決まった向きに流す、から選べ、フリッカーも付けられます。
入力をつなぐと合成方法（オーバーレイ・ソフトライト・乗算・スクリーン・加算・通常）で重ね、入力のアルファは保たれます。何もつながないとテクスチャだけを出力し、傷・汚れは透明の背景に出るのでそのまま Merge に重ねられます。

■ 使い方

  1. Edit ページの「エフェクト」→ Fusion エフェクト →「動くテクスチャ」をクリップにドラッグ。または Fusion ページで MotionTexture ノード（Fuses カテゴリ）を追加する
  2. 「テクスチャ」で種類を選び、「動き」で止める・コマごとに変える・流れるを選ぶ
  3. 強さ・大きさ・合成方法と、種類ごとの項目（傷の量、しわの深さ、粒の大きさなど）をインスペクタで調整する

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。GPU（Metal / CUDA / OpenCL）で処理するため、無料版では動かない（Studio 限定の）可能性があります
