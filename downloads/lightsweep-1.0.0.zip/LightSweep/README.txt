LightSweep 1.0.0
========================================

画像の上を光の帯が通り過ぎるノード

ロゴや文字の上を光の帯がサッと通り過ぎる、ライトスイープのノードです。帯の位置は進行度（0 = 被写体の手前、1 = 通り過ぎた後）で決め、キーフレームで 0 → 1 に動かします。速さの変化はイージングの種類と強さで調整できます。
初期設定では画像のアルファがある所だけに光が当たり、帯は被写体の端から端まで通過します。帯の幅・やわらかさ・色・強さ・角度、形（やわらか／くっきり／二重線）、合成方法（加算／スクリーン）を変えられます。

■ 使い方

  1. Fusion ページで LightSweep ノード（Fuses カテゴリ）を追加して画像をつなぐ。または Edit ページの「エフェクト」→ Fusion エフェクト →「ライトスイープ」をクリップにドラッグ
  2. 「進行度」に 0 と 1 のキーフレームを打つ（間隔が通過の速さ）
  3. イージング・幅・色・角度などをインスペクタで調整する

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。GPU（Metal / CUDA / OpenCL）で処理するため、無料版では動かない（Studio 限定の）可能性があります
