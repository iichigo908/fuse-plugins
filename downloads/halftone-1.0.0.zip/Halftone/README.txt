Halftone 1.0.0
========================================

画像を網点（ハーフトーン）にするノード

画像を網点（ハーフトーン）に変えるノードです。回転したグリッドにドットが並び、画像の明るさでドットの大きさが変わります。Fusion ページのノードとして、また Edit ページのエフェクトとして使えます。
ドットの形は 8 種類。モノクロ、画像の色、印刷風の CMYK の 3 つのモードがあり、サイズ・角度・色を自由に変えられます。直線・円・マスクで適用範囲を決めて、途中からだんだんハーフトーンになる表現もできます。

■ 使い方

  1. Fusion ページで Halftone ノード（Fuses カテゴリ）を追加して画像をつなぐ。または Edit ページの「エフェクト」→ Fusion エフェクト →「ハーフトーン」をクリップにドラッグ
  2. 形・モード・サイズ・角度・色を決める
  3. 「Area」ページ（Edit ページでは「適用範囲」）で、ハーフトーンにする範囲となじませ方を決める

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。GPU（Metal / CUDA / OpenCL）で処理するため、無料版では動かない（Studio 限定の）可能性があります
