TelopAnim 1.0.0
========================================

バラエティ番組風のテロップアニメ

テロップをぷるぷる・ぐにゃぐにゃ・ガクガクさせる、バラエティ番組風のアニメーション 22 種です。Edit ページのエフェクトとして入るので、Text+ などのタイトルクリップにドラッグするだけで動きます。
登場（IN）・ループ・退場（OUT）があり、クリップの頭と最後に自動で合わせます。揺れ幅・細かさ・向きなどをエフェクトごとに調整できます。

■ 使い方

  1. Edit ページの「エフェクト」→ Fusion エフェクト →「テロップアニメ」を開く
  2. 使いたい動きを Text+ などのタイトルクリップにドラッグする
  3. インスペクタで揺れ幅や長さを調整する

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows は未確認。GPU（Metal / CUDA / OpenCL）で処理

■ クレジット

  Easing functions based on Robert Penner's easing equations (BSD License) http://robertpenner.com/easing/

  ライセンス表記は THIRD_PARTY_NOTICES.txt にあります。
