ShapeMorph 1.0.0
========================================

2つの画像の形を変形させてつなぐトランジション

Background の画像の形が、Foreground の画像の形へなめらかに変形していくトランジションです。ロゴ、図形、Text+、キーイングした素材など、アルファのある画像ならそのまま使えます。
Morph を 0 から 1 へキーフレームで動かすだけで使えます。変形しながら位置・大きさ・回転を合わせることもできます。

■ 使い方

  1. Fusion ページで ShapeMorph ノードを追加する（Fuses カテゴリ）
  2. 始まりの画像を Background、終わりの画像を Foreground につなぐ
  3. Morph を 0 → 1 にキーフレームで動かす

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。Studio 限定（無料版では動かない）の可能性があります

■ クレジット

  Easing functions based on Robert Penner's easing equations (BSD License) http://robertpenner.com/easing/

  ライセンス表記は THIRD_PARTY_NOTICES.txt にあります。
