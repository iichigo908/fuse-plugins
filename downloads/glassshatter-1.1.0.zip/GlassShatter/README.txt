GlassShatter 1.1.0
========================================

画像がガラスのように割れて砕けるエフェクト

静止画や映像がガラスのように割れて、破片になって飛び散るエフェクトです。進行度 0 → 1 で割れが進み、ひびが入ってから破片が外れ、最後には何も残りません。割れたあとは透明になるので、下のトラックが見えます。
割れ方は 2 種類。衝撃の位置からひびが広がって中心から崩れていくタイプと、全体が同時に割れて手前に飛んでくるタイプです。破片は立体的に傾いて回転し、向きによる明暗とガラスの切り口がつきます。

■ 使い方

  1. Edit ページの「エフェクト」→ Fusion エフェクト →「ガラス割れ」を開く
  2. 使いたいエフェクトを静止画などのクリップにドラッグする（自動は勝手に割れる、進行度はキーフレームで動かす）
  3. インスペクタで衝撃の位置・破片の数・飛ぶ方向などを調整する
  4. Fusion ページでは GlassShatter ノード（Fuses カテゴリ）か、Effects ライブラリ → Templates →「ガラス割れ」を使う

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。GPU（Metal / CUDA / OpenCL）で処理するため、無料版では動かない（Studio 限定の）可能性があります
