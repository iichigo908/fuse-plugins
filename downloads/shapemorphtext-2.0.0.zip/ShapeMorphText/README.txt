ShapeMorphText 2.0.0
========================================

図形が1文字ずつ文字に変形していくジェネレーター

色付きの図形が画面に散らばった位置から飛んできて、1文字ずつ文字に変形するテキストアニメーションです。入力のないジェネレーターなので、Merge で背景に重ねて使います。
図形の形や色、文字ごとのサイズ・色・フォント、変化のタイミングとイージングを自由に設定できます。日本語にも対応しています。

■ 使い方

  1. Fusion ページで ShapeMorphText ノードを追加する（Fuses カテゴリ）
  2. Merge の Foreground につなぎ、背景を Background につなぐ
  3. Text ページで文字を入力し、Shape・Animation・Color ページで動きと見た目を決める

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。Studio 限定（無料版では動かない）の可能性があります

■ クレジット

  Shape SDFs based on Inigo Quilez https://iquilezles.org
  Easing functions based on Robert Penner's easing equations (BSD License) http://robertpenner.com/easing/

  ライセンス表記は THIRD_PARTY_NOTICES.txt にあります。
