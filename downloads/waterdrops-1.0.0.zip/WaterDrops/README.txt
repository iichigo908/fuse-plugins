WaterDrops 1.0.0
========================================

ガラスに付いた水滴の歪みと透明感を重ねるノード

画像の上にガラスに付いた水滴を重ねるノードです。水滴はレンズのように後ろの画像を屈折させ（拡大・上下反転）、ハイライト、反対側の明るい三日月、暗い縁、やわらかい影で透明感を出します。
2 つ目の入力「Area Mask」にマスクやアルファのある画像をつなぐと、その範囲にだけ水滴が付きます（つながないときは画面全体）。水滴の間のガラスをぼかす「くもり」や、水滴が順に現れる「出現」（0 → 1）も使えます。

■ 使い方

  1. Fusion ページで WaterDrops ノード（Fuses カテゴリ）を追加して画像をつなぐ。または Edit ページの「エフェクト」→ Fusion エフェクト →「水滴」をクリップにドラッグ
  2. 範囲を決めたいときは、Fusion ページで Ellipse / Polygon などのマスクを 2 つ目の入力（Area Mask）につなぐ
  3. 屈折・大きさ・密度・くもりなどをインスペクタで調整。水滴を順に出したいときは「出現」に 0 と 1 のキーフレームを打つ

■ インストール

  Mac
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_mac.command をダブルクリックする（初回は右クリック →「開く」）
    3. DaVinci Resolve を起動する

  Windows
    1. DaVinci Resolve を終了する
    2. zip を展開し、install_windows.bat をダブルクリックする
    3. DaVinci Resolve を起動する

  手動で入れる場合は、zip 内の Fusion フォルダの中身を Fusion のユーザーフォルダにコピーします。Mac: ~/Library/Application Support/Blackmagic Design/DaVinci Resolve/Fusion/ ／ Windows: %APPDATA%\Blackmagic Design\DaVinci Resolve\Support\Fusion\

■ 動作環境

  DaVinci Resolve Studio 21.1（Mac）で動作確認。Windows・無料版は未確認。GPU（Metal / CUDA / OpenCL）で処理するため、無料版では動かない（Studio 限定の）可能性があります
